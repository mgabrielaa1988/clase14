#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char nombre[20];
    int edad;
} eAlumno;

int main()
{
    /*eAlumno auxiliarAlumno;
    eAlumno* punteroAlumno;
    punteroAlumno = &auxiliarAlumno;

    printf("Ingrese nombre: ");
    fflush(stdin);
    scanf("%[^\n]",(*punteroAlumno).nombre);
    printf("Ingrese edad: ");
    scanf("%d",&(*punteroAlumno).edad);
    printf("\nUsted ingreso\nNombre: %s\nEdad: %d\n\n",punteroAlumno->nombre,punteroAlumno->edad);*/

    int i;
    eAlumno personas[3];
    eAlumno *ptrPersona;
    ptrPersona = personas;

    /*for(i=0;i<3;i++){
        printf("Ingrese nombre: ");
        fflush(stdin);
        scanf("%[^\n]",personas[i].nombre);
        printf("Ingrese edad: ");
        scanf("%d",&personas[i].edad);
    }*/
    for(i=0;i<3;i++){
        printf("Ingrese nombre: ");
        fflush(stdin);
        scanf("%[^\n]",(*(ptrPersona+i)).nombre);//no modifica la direccion a donde apunta el puntero
        printf("Ingrese edad: ");//se salta la cantidad que indica i, en este caso de a 1 estructura
        scanf("%d",&(*(ptrPersona+i)).edad);
    }
    printf("\n\nUsted ingreso\n");
    for(i=0;i<3;i++){
        printf("\nNombre: %s\nEdad: %d",ptrPersona->nombre,ptrPersona->edad);
        ptrPersona++;
    }

    return 0;
}
