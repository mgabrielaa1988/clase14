#include <stdio.h>
#include <stdlib.h>

void mostrarCadena(char*);

int main()
{
    char cadena[] = "hola";
    mostrarCadena(cadena);

    return 0;
}

/** \brief Muestra una cadena de caracteres
 * \param punteroCadena Puntero a char que recibe una cadena de caracteres
 */
void mostrarCadena(char* punteroCadena)
{
    while(*punteroCadena != '\0')
    {
        printf("%c",*punteroCadena);
        punteroCadena++; //suma 1*sizeof del tipo dedato a la direccion de memoria,
    }                   //o sea, se mueveun lugar(aritmetica de punteros)
}
